<table class="table table-bordered table-striped" style="width: 100%">
	<tr>
		<td valign="top" style="width:200px">No Urut Addendum</td>
		<td valign="top">:</td>
		<td valign="top" style="color:#9900cc"><?=$dtdefault->No_Urut_Add?></td>
	</tr>
	<tr>
		<td valign="top">Addendum Kontrak</td>
		<td valign="top">:</td>
		<td valign="top" style="color:#9900cc"><?=$dtdefault->Desc_AddKontrak?></td>
	</tr>
	<tr>
		<td valign="top">Proforma Kesepakatan Pelatihan</td>
		<td valign="top">:</td>
		<td valign="top" style="color:#9900cc"><?=$dtdefault->Desc_ProformaKontrak?></td>
	</tr>
	<tr>
		<td valign="top">Perusahaan/Instansi</td>
		<td valign="top">:</td>
		<td valign="top" style="color:#9900cc"><?=$dtdefault->Desc_PershInstansi?></td>
	</tr>
	<tr>
		<td valign="top">Nilai Rp</td>
		<td valign="top">:</td>
		<td valign="top" style="color:#9900cc"><?=$dtdefault->Nilai_Rp?></td>
	</tr>
	<tr>
		<td valign="top">Rencana Jumlah Peserta</td>
		<td valign="top">:</td>
		<td valign="top" style="color:#9900cc"><?=$dtdefault->Rencana_JmlPeserta?></td>
	</tr>
	<tr>
		<td valign="top">Rencana Tempat Penyelenggaraan</td>
		<td valign="top">:</td>
		<td valign="top" style="color:#9900cc"><?=$dtdefault->Rencana_TempatSelenggara?></td>
	</tr>
	<tr>
		<td valign="top">File Lampiran</td>
		<td valign="top">:</td>
		<td valign="top"><?='<a href="'.base_url('uploads/fileapps/'.$dtdefault->File_Lampiran).'" download><i class="fa fa-download"></i> File Lampiran</a>'?>
	</tr>
</table>