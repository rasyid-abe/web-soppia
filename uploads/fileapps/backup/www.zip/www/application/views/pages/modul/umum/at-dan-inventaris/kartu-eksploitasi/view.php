<table class="table table-bordered table-striped" style="width: 100%">
	<tr>
		<td valign="top">Kategori AT dan Inventaris</td>
		<td valign="top">:</td>
		<td valign="top">Inventaris</td>
	</tr>
	<tr>
		<td valign="top">No AT dan Inventaris</td>
		<td valign="top">:</td>
		<td valign="top">54658465</td>
	</tr>
	<tr>
		<td valign="top">Nama Barang</td>
		<td valign="top">:</td>
		<td valign="top">Kursi Kantor</td>
	</tr>
	
</table>
<table class="table table-bordered table-striped" style="width: 100%">

	<tr><header style="text-align: center; font-size: 20px">PENGADAAN INVETARIS</header></tr>
	<tr>
		<td valign="top">Tanggal Beli</td>
		<td valign="top">:</td>
		<td valign="top">Inventaris</td>
	</tr>
	<tr>
		<td valign="top">Harga Barang</td>
		<td valign="top">:</td>
		<td valign="top">Rp 100.000.000</td>
	</tr>
	<tr>
		<td valign="top">Bukti Pembelian (jpg/jpeg/png)</td>
		<td valign="top">:</td>
		<td valign="top">Bukti.jpg</td>
	</tr>
	<tr>
		<td valign="top">Keterangan</td>
		<td valign="top">:</td>
		<td valign="top">Barang Baru</td>
	</tr>
	
</table>
<table class="table table-bordered table-striped" style="width: 100%">

	<tr><header style="text-align: center; font-size: 20px">PENGGUNAAN INVETARIS</header></tr>
	<tr>
		<td valign="top">Penanggung Jawab</td>
		<td valign="top">:</td>
		<td valign="top">Ahmad Subekti</td>
	</tr>
	<tr>
		<td valign="top">Tanggl Pinjam</td>
		<td valign="top">:</td>
		<td valign="top">15 Januari 2018</td>
	</tr>
	<tr>
		<td valign="top">Tanggal Kembali</td>
		<td valign="top">:</td>
		<td valign="top">12 Januari 2018</td>
	</tr>
	<tr>
		<td valign="top">Keterangan</td>
		<td valign="top">:</td>
		<td valign="top">Cacat bagian kursi</td>
	</tr>
	
</table>
<table class="table table-bordered table-striped" style="width: 100%">

	<tr><header style="text-align: center; font-size: 20px">PEMELIHARAAN INVETARIS</header></tr>
	<tr>
		<td valign="top">Penanggung Jawab</td>
		<td valign="top">:</td>
		<td valign="top">Siswono</td>
	</tr>
	<tr>
		<td valign="top">Tanggal/Jam</td>
		<td valign="top">:</td>
		<td valign="top">12 Januari 2018/13.00</td>
	</tr>
	<tr>
		<td valign="top">Biaya</td>
		<td valign="top">:</td>
		<td valign="top">20.000.000</td>
	</tr>
	<tr>
		<td valign="top">Keterangan</td>
		<td valign="top">:</td>
		<td valign="top">Perbaikan Meja Kantor</td>
	</tr>
	
</table>
<table class="table table-bordered table-striped" style="width: 100%">

	<tr><header style="text-align: center; font-size: 20px">PENYIMPANAN INVETARIS</header></tr>
	<tr>
		<td valign="top">Lokasi Penyimpanan</td>
		<td valign="top">:</td>
		<td valign="top">Gudang Paling Selatan</td>
	</tr>
	
</table>
<table class="table table-bordered table-striped" style="width: 100%">

	<tr><header style="text-align: center; font-size: 20px">DEPRESIASI</header></tr>
	<tr>
		<td valign="top">Tanggal Pembebanan</td>
		<td valign="top">:</td>
		<td valign="top">12 Januari 2018</td>
	</tr>
	<tr>
		<td valign="top">Nilai(ruapiah)</td>
		<td valign="top">:</td>
		<td valign="top">Rp 15.000.000</td>
	</tr>
	
</table>