<table class="table table-bordered table-striped" style="width: 100%">

	<tr>
		<td valign="top">Kategori AT dan Inventaris</td>
		<td valign="top">:</td>
		<td valign="top"><?=($dtdefault->Flag_AT_or_Inv == "AT")?'Aktiva Tetap':'Inventory';?></td>
	</tr>
	<tr>
		<td valign="top">No AT dan Inventaris</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->no_at_inv?></td>
	</tr>
	<tr>
		<td valign="top">Nama Barang</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->Desc_AT_n_Invent?></td>
	</tr>
	<tr>
		<td valign="top">Deskripsi Pemeliharaan</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->Desc_Transaksi?></td>
	</tr>
	<tr>
		<td valign="top">Penanggung Jawab</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->PenanggungJwb?></td>
	</tr>
	<tr>
		<td valign="top">Tanggal/Jam</td>
		<td valign="top">:</td>
		<td valign="top"><?=tgl_indo($dtdefault->Tgl_TransaksiAwal)?></td>
	</tr>
	<tr>
		<td valign="top">Biaya</td>
		<td valign="top">:</td>
		<td valign="top"><?=number_format($dtdefault->Nilai_Rp)?></td>
	</tr>
	<tr>
		<td valign="top">Keterangan</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->Keterangan?></td>
	</tr>
</table>