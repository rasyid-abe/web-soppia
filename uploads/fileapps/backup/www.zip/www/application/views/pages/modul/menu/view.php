<table class="table table-bordered table-striped" style="width: 100%">
	<tr>
		<td valign="top">Nama Menu</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dt->name?></td>
	</tr>
	<tr>
		<td valign="top">Parent Menu</td>
		<td valign="top">:</td>
		<td valign="top"><?=getmenuname($dt->parent)?></td>
	</tr>
	<tr>
		<td valign="top">Url</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dt->url?></td>
	</tr>
	<tr>
		<td valign="top">Icon</td>
		<td valign="top">:</td>
		<td valign="top"><?=($dt->icon =='' || $dt->icon == null)?'':'<i class="'.$dt->icon.'"></i>';?></td>
	</tr>
	<tr>
		<td valign="top">Label</td>
		<td valign="top">:</td>
		<td valign="top"><?=getlabelname($dt->labelmenu)?></td>
	</tr>
	<tr>
		<td valign="top">Aktif</td>
		<td valign="top">:</td>
		<td valign="top"><?=($dt->active == '1')?'Ya':'Tidak';?></td>
	</tr>
	<tr>
		<td valign="top">Keterangan</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dt->description?></td>
	</tr>
</table>