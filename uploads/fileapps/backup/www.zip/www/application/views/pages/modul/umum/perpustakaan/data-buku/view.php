<table class="table table-bordered table-striped" style="width: 100%">
	<tr>
		<td valign="top">Judul Buku</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->judul_buku?></td>
	</tr>
	<tr>
		<td valign="top">Penerbit Buku</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->penerbit?></td>
	</tr>
	<tr>
		<td valign="top">Pengarang Buku</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->pengarang?></td>
	</tr>
	<tr>
		<td valign="top">Tahun Buku</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->tahun_buku?></td>
	</tr>
	<tr>
		<td valign="top">Jumlah Buku</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->jumlah_buku?></td>
	</tr>
	<tr>
		<td valign="top">Lokasi Buku</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->rak?></td>
	</tr>
	<tr>
		<td valign="top">Tanggal Masuk</td>
		<td valign="top">:</td>
		<td valign="top"><?=tgl_indo($dtdefault->tanggal_masuk)?></td>
	</tr>
</table>