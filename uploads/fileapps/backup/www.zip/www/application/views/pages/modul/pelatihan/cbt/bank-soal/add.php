<link rel="stylesheet" href="<?=base_url("assets/adminlte/bower_components/select2/dist/css/select2.min.css")?>">
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    <?=$titlepage?>
    <small><?=$subtitlepage?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?=base_url("dashboard")?>"><i class="fa fa-dashboard"></i> <?=$breadcrumb1?></a></li>
    <li><a ><?=$breadcrumb2?></a></li>
    <li class="active"><?=$breadcrumb3?></li>
  </ol>
</section>

<!-- Main content -->
<section class="content">

  <?php if($this->session->flashdata('error')){ ?>
    <br>
    <div class="alert alert-danger"><?=$this->session->flashdata('error')?></div>
  <?php }else if($this->session->flashdata('success')){ ?>
    <br>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>

    <div class="row ">
      <div class="col-md-12"> 
        <div class="box box-success">         
          <div class="box-header with-border">
            <h3 class="box-title"><?=$titlebox?></h3>
            
            <div class="box-tools pull-right">
                <a href="<?=base_url($this->uri->segment(1).'/'.$this->uri->segment(2))?>" class="btn btn-box-tool" data-toggle="tooltip"
                    title="Kembali Ke Manage <?=$subtitlepage?>">
                <i class="fa fa-arrow-circle-left"></i> Back</a>
            <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="Refresh Page" onclick='location.reload();'>
                <i class="fa fa-refresh"></i> Refresh</button>
            </div>
          </div>
          <div class="box-body">
            <form action="<?=base_url($this->uri->segment(1)."/".$this->uri->segment(2)."/store")?>" method="POST">
            <input type="hidden" name="<?=$this->security->get_csrf_token_name()?>" value="<?=$this->security->get_csrf_hash()?>" />  
            
            <div class="form-group col-sm-12" align="center">
                <h3><img src="http://soppia.com/assets/images/soppia.png" width="70" height="70" /> <b>YAYASAN PENDIDIKAN INTERNAL AUDITOR (YPIA)</b></h3>
            </div>
            
            <div class="form-group col-sm-12">
                <hr style="margin-bottom:0;margin-top:0" />
            </div>
            
            <div class="form-group col-sm-12">
                <div class="col-sm-2">
                  <label>Nama Instruktur</label>
                </div>
                <div class="col-sm-1">
                  <label>:</label>
                </div>
                <div class="col-sm-8">
                  <select  class="form-control select2" name="instruktur">
                      <option value="" selected readonly>Pilih Instruktur</option>
                      <?php
                        foreach ($instruktur->result() as $data) {
                          $slcb1 = ($this->session->flashdata('oldinput')['instruktur'] == $data->Id_Instruktur)? 'selected':'';
                      ?>
                          <option value="<?=$data->Id_Instruktur?>" <?=$slcb1?> ><?=$data->NamaLengkap_DgnGelar?></option>
                      <?php
                        }
                      ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group col-sm-12">
                <div class="col-sm-2">
                  <label>Materi Pelatihan</label>
                </div>
                <div class="col-sm-1">
                  <label>:</label>
                </div>
                <div class="col-sm-8">
                  <select  class="form-control select2" name="materipel">
                      <option value="" selected readonly>Materi dan Aktifitas</option>
                      <?php
                        foreach ($materi->result() as $data) {
                          $slcb1 = ($this->session->flashdata('oldinput')['materipel'] == $data->Kd_Materi_n_Aktifitas)? 'selected':'';
                      ?>
                          <option value="<?=$data->Kd_Materi_n_Aktifitas?>" <?=$slcb1?> ><?=$data->Desc_Materi_n_Aktifitas?></option>
                      <?php
                        }
                      ?>
                    </select>
                </div>
            </div>
                
            <div class="form-group col-sm-12">
                <div class="col-sm-2">
                  <label>Materi Sub Bab</label>
                </div>
                <div class="col-sm-1">
                  <label>:</label>
                </div>
                <div class="col-sm-8">
                  <select  class="form-control select2" name="subbabm">
                      <option value="" selected readonly>Materi dan Aktifitas</option>
                      <?php
                        foreach ($subbab->result() as $data) {
                          $slcb1 = ($this->session->flashdata('oldinput')['subbabm'] == $data->Kd_SubBab)? 'selected':'';
                      ?>
                          <option value="<?=$data->Kd_SubBab?>" <?=$slcb1?> ><?=$data->Desc_SubBab?></option>
                      <?php
                        }
                      ?>
                 </select>
              </div>   
            </div> <!--form-group--> 
              
              <div class="form-group col-sm-12">
                <hr style="margin-bottom:0;margin-top:0" />
              </div>
            
              <div class="container" style="margin-left:40px">
                  
              </div> <!--container--> <br/>
            
            <div class="form-group col-sm-12">
              <hr style="margin-bottom:0;margin-top:0" />
            </div>

            <div class="form-group col-sm-12"> 
              <div class="col-sm-3 pull-right">
                <button type="submit" title="Simpan Data" class="btn btn-block btn-flat btn-success" onclick="return confirm('Apakah Anda yakin dengan data tersebut ?')">Save</button>
              </div>
              <div class="col-sm-3 pull-right">
                <a href="<?=base_url($this->uri->segment(1).'/'.$this->uri->segment(2))?>" title="Kembali" class="btn btn-danger btn-block btn-flat">Back</a>
              </div>
            </div>
            
          </div><!-- /.box-body -->
          </form>
        </div> <!-- box-success -->
      </div> <!-- col -->
    </div> <!-- row -->
</section>

<script src="<?=base_url("assets/adminlte/bower_components/select2/dist/js/select2.full.min.js")?>"></script>
<script type="text/javascript">  
  $(function () {
    $('.select2').select2();
  });
</script>