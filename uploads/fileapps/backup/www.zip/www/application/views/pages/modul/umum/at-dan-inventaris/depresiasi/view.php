<table class="table table-bordered table-striped" style="width: 100%">

	<tr>
		<td valign="top">Kategori AT dan Inventaris</td>
		<td valign="top">:</td>
		<td valign="top">Inventaris</td>
	</tr>
	<tr>
		<td valign="top">No AT dan Inventaris</td>
		<td valign="top">:</td>
		<td valign="top">54658465</td>
	</tr>
	<tr>
		<td valign="top">Nama Barang</td>
		<td valign="top">:</td>
		<td valign="top">Kursi Kantor</td>
	</tr>
	<tr>
		<td valign="top">Tanggal Pembebanan</td>
		<td valign="top">:</td>
		<td valign="top">10 November 2018</td>
	</tr>
	<tr>
		<td valign="top">Nilai (Rupiah)</td>
		<td valign="top">:</td>
		<td valign="top">200.000</td>
	</tr>
	
</table>