<?php
 if(accessperm('melihat-data-proforma-kontrak')){ 
?>
<table class="table table-bordered table-striped" style="width: 100%">
<tr>
  <td valign="top">Proforma Kontrak Pelatihan</td>
  <td valign="top">:</td>
  <td valign="top"><?=$proforma->row()->Desc_ProformaKontrak?></td>
</tr>
<tr>
  <td valign="top">Nomor Proforma Kontrak</td>
  <td valign="top">:</td>
  <td valign="top"><?=$proforma->row()->No_ProformaKontrak?></td>
</tr>
<tr>
  <td valign="top">Perusahaan / Instansi</td>
  <td valign="top">:</td>
  <td valign="top"><?=$proforma->row()->Desc_PershInstansi?></td>
</tr>
<tr>
  <td valign="top">Nilai Rp</td>
  <td valign="top">:</td>
  <td valign="top">Rp. <?=number_format($proforma->row()->Nilai_Rp)?></td>
</tr>
<tr>
  <td valign="top">Rencana Jumlah Peserta</td>
  <td valign="top">:</td>
  <td valign="top"><?=$proforma->row()->Rencana_JmlPeserta?></td>
</tr>
<tr>
  <td valign="top">Rencana Tempat Penyelenggaraan</td>
  <td valign="top">:</td>
  <td valign="top"><?=$proforma->row()->Rencana_TempatSelenggara?></td>
</tr>
<tr>
  <td valign="top">File Lampiran </td>
  <td valign="top">:</td>
  <td valign="top"><?=($proforma->row()->File_Lampiran == null )? '' : '<a href="'.base_url('uploads/fileapps/proformakontrak/'.$proforma->row()->File_Lampiran).'" download><i class="fa fa-download"></i> File Lampiran</a>'?></td>
</tr>
</table>

<div class="box">
  <div class="box-header  with-border">
    <h3 class="box-title">Accounting Jurnal</h3>
  </div>
  <div class="box-body">
        <div class="row">
            <div class="col-sm-6">
                <table class="table table-bordered table-striped" style="width: 100%">
                    <thead>
                        <tr>
                          <td valign="top">Deskripsi</td>
                          <td valign="top">Status</td>
                          <td valign="top">Nilai</td>
                        </tr>
                    <thead>
               <?php
                foreach($acc_jur->result() as $accj){
                    if($accj->Flag_D_or_K == "D"){
                ?>
                    <tr class="success">
                      <td valign="top"><?php
                        $desc = $this->db->where(array("idproforma"=>$accj->FId_Proforma,"Flag_GrupAccount"=>"A","Flag_Proforma_or_Kelas"=>"P"))->get("mst_subaccount_soppia");
                        echo $desc->row()->Desc_Account;
                      ?></td>
                      <td valign="top">DEBIT</td>
                      <td valign="top"><?=number_format($accj->Nilai_Rps)?></td>
                    </tr>
                <?php
                    }
                }
               ?>
               </table>
               </div>
               <div class="col-sm-6">
                <table class="table table-bordered table-striped" style="width: 100%">
                    <thead>
                        <tr>
                          <td valign="top">Deskripsi</td>
                          <td valign="top">Status</td>
                          <td valign="top">Nilai</td>
                        </tr>
                    <thead>
               <?php
                foreach($acc_jur->result() as $accj){
                    if($accj->Flag_D_or_K == "K"){
                ?>
                    <tr class="warning">
                      <td valign="top"><?php
                        $desc = $this->db->where(array("idproforma"=>$accj->FId_Proforma,"Flag_GrupAccount"=>"R","Flag_Proforma_or_Kelas"=>"P"))->get("mst_subaccount_soppia");
                        echo $desc->row()->Desc_Account;
                      ?></td>
                      <td valign="top">KREDIT</td>
                      <td valign="top"><?=number_format($accj->Nilai_Rps)?></td>
                    </tr>
                <?php
                    }
                }
               ?>
               </table>
           </div>
       </div>
  </div>
</div>
<?php
  }else{
    echo "anda tidak memiliki akses untuk melihat ini!";
  }
?>