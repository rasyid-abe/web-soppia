<table class="table table-bordered table-striped" style="width: 100%">

	<tr>
		<td valign="top">Kategori AT dan Inventaris</td>
		<td valign="top">:</td>
		<td valign="top"><?php
		        $data = $dtdefault->FId_ATnInvent;
        	    $getno = '' ;
        	    if($data != null || $data != ''){
        	        $getno = $this->db->where(array("Id_AT_n_Invent"=>$data))->get("mst_at_n_invent");
        	        $getno = $getno->row()->no_at_inv;
        	    }else{
        	        $getno = "<code>N/A</code>";
        	    }
        	    echo $getno;
		?></td>
	</tr>
	<tr>
		<td valign="top">No AT dan Inventaris</td>
		<td valign="top">:</td>
		<td valign="top"><?php
        	    $getflag = '' ;
        	    if($data != null || $data != ''){
        	        $getflag = $this->db->where(array("Id_AT_n_Invent"=>$data))->get("mst_at_n_invent");
        	        $getflag = $getflag->row()->Flag_AT_or_Inv;
        	        if($getflag == "INV"){
        	            $getflag = "INVENTARIS";
        	        }else{
        	            $getflag = "AKTIVA TETAP";
        	        }
        	    }else{
        	        $getflag = "<code>N/A</code>";
        	    }
        	    echo $getflag;
		?></td>
	</tr>
	<tr>
		<td valign="top">Nama Barang</td>
		<td valign="top">:</td>
		<td valign="top">
		    <?php
            	    $getnamabarang = '' ;
            	    if($data != null || $data != ''){
            	        $getnamabarang = $this->db->where(array("Id_AT_n_Invent"=>$data))->get("mst_at_n_invent");
            	        $getnamabarang = $getnamabarang->row()->Desc_AT_n_Invent;
            	    }else{
            	        $getnamabarang = "<code>N/A</code>";
            	    }
            	    echo $getnamabarang;
            	
		    ?>
		</td>
	</tr>
	<tr>
		<td valign="top">Penanggung Jawab</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->PenanggungJwb?></td>
	</tr>
	<tr>
		<td valign="top">Tanggal Pinjam</td>
		<td valign="top">:</td>
		<td valign="top"><?=tgl_indo($dtdefault->Tgl_TransaksiAwal)?></td>
	</tr>
	<tr>
		<td valign="top">Tanggal Kembali</td>
		<td valign="top">:</td>
		<td valign="top"><?=tgl_indo($dtdefault->Tgl_TransaksiAkhir)?></td>
	</tr>
	<tr>
		<td valign="top">Keterangan</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->Keterangan?></td>
	</tr>
</table>