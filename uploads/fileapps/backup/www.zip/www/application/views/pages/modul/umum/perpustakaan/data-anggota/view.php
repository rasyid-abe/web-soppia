<table class="table table-bordered table-striped" style="width: 100%">
	<tr>
		<td valign="top">Nomor KTP</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->noktp?></td>
	</tr>
	<tr>
		<td valign="top">Nama Anggota</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->nama_anggota?></td>
	</tr>
	<tr>
		<td valign="top">Alamat</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->alamat?></td>
	</tr>
	<tr>
		<td valign="top">Nomor HP</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->nohp?></td>
	</tr>
	<tr>
		<td valign="top">Tanggal Daftar</td>
		<td valign="top">:</td>
		<td valign="top"><?=tgl_indo($dtdefault->tgl_daftar)?></td>
	</tr>
</table>