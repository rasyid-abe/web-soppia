  <!-- Custom Tabs -->
  <div class="nav-tabs-custom">
    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab_1" data-toggle="tab"><b>Informasi Ruangan</b></a></li>
      <li><a href="#tab_2" data-toggle="tab"><b>Informasi Pemakaian</b></a></li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab_1">
		<table class="table table-bordered table-striped" style="width: 100%">
        	<tr>
        		<td valign="top">Nama Ruangan</td>
        		<td valign="top">:</td>
        		<td valign="top"><?=$dtdefault->Desc_RuangLantai?></td>
        	</tr>
        	<tr>
        		<td valign="top">Nomor Lantai</td>
        		<td valign="top">:</td>
        		<td valign="top"><?=$dtdefault->No_Lantai?></td>
        	</tr>
        	<tr>
        		<td valign="top">Keterangan</td>
        		<td valign="top">:</td>
        		<td valign="top"><?=$dtdefault->Keterangan?></td>
        	</tr>
		</table>        
      </div>
      <!-- /.tab-pane -->
      <div class="tab-pane" id="tab_2">
        <table class="table table-bordered table-striped" style="width: 100%">
			<tr>
        		<td valign="top">Tanggal Mulai</td>
        		<td valign="top">:</td>
        		<td valign="top"><?=tgl_indo($dtdefault->tgl_mulai)?></td>
        	</tr>	
        	<tr>
        		<td valign="top">Tanggal Selesai</td>
        		<td valign="top">:</td>
        		<td valign="top"><?=tgl_indo($dtdefault->tgl_selesai)?></td>
        	</tr>	
        	<tr>
        		<td valign="top">Penanggung Jawab</td>
        		<td valign="top">:</td>
        		<td valign="top"><?=$dtdefault->petugas?></td>
        	</tr>	
        	<tr>
        		<td valign="top">Keterangan</td>
        		<td valign="top">:</td>
        		<td valign="top"><?=$dtdefault->keterangan_pakai?></td>
        	</tr>	
		</table>
      </div>
      <!-- /.tab-pane -->
    </div>
    <!-- /.tab-content -->
  </div>
  <!-- nav-tabs-custom -->
