<table class="table table-bordered table-striped" style="width: 100%">	
	<tr>
		<td valign="top">Kelas</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->DescBebas_Kelas_n_Angkatan?></td>
	</tr>
	<tr>
		<td valign="top">No Urut Hari</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->No_Urut_Hari?></td>
	</tr>
	<tr>
		<td valign="top">Tanggal</td>
		<td valign="top">:</td>
		<td valign="top"><?=tgl_indo($dtdefault->Tgl)?></td>
	</tr>
	<tr>
		<td valign="top">Hari</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->Hari?></td>
	</tr>
	<tr>
		<td valign="top">No Urut Sesi</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->No_Urut_Sesi?></td>
	</tr>
	<tr>
		<td valign="top">Deskripsi Sesi</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->Desc_Sesi?></td>
	</tr>
	<tr>
		<td valign="top">Deskripsi Materi</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->Desc_Materi_n_Aktifitas?></td>
	</tr>
	<tr>
		<td valign="top">Nama Instruktur</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->NamaLengkap_DgnGelar?></td>
	</tr>
</table>