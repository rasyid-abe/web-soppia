<section class="content-header">
  <h1>
    Laporan Biaya dan Pendapatan Kelas Reguler
    <small>Data Laporan</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?=base_url("dashboard")?>"><i class="fa fa-dashboard"></i> <?=$breadcrumb1?></a></li>
    <li><a><?=$breadcrumb2?></a></li>
    <li class="active">Data Laporan</li>
  </ol>
</section>

<section class="content">

  <?php if($this->session->flashdata('error')){ ?>
    <br>
    <div class="alert alert-danger"><?=$this->session->flashdata('error')?></div>
  <?php }else if($this->session->flashdata('success')){ ?>
    <br>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>

  <!-- Default box -->
  <div class="box" style="border-top:0px solid">
    <div class="box-header with-border">
      <h3 class="box-title">Manage Laporan Biaya dan Pendapatan Kelas Reguler</h3>

      <div class="box-tools pull-right">
        <?php $data = $kelas->row();?>
        <?php if(accessperm('menambahkan-data-pembebanan-biaya-kelas')){ ?>
          <a href="<?=base_url("reguler/accounting-jurnal/add/".$data->Id_Kelas_n_Angkatan)?>" class="btn btn-box-tool" data-toggle="tooltip" title="Pengeluaran Biaya Kelas Reguler"> <i class="fa fa-plus-circle"></i> Biaya</a>
        <?php }else{?>
          <a class="btn btn-box-tool" data-toggle="tooltip" title="No Access"><i class="fa fa-plus-circle"></i> No Access</a>
        <?php }?>
        <?php if(accessperm('menambahkan-data-pembebanan-biaya-kelas')){ ?>
          <a href="<?=base_url("reguler/accounting-jurnal/pendapatan/".$data->Id_Kelas_n_Angkatan)?>" class="btn btn-box-tool" data-toggle="tooltip" title="Pemasukan Pendapatan Kelas Reguler"> <i class="fa fa-plus-circle"></i> Pendapatan</a>
        <?php }else{?>
          <a class="btn btn-box-tool" data-toggle="tooltip" title="No Access"><i class="fa fa-plus-circle"></i> No Access</a>
        <?php }?>
        <a href="<?=base_url($this->uri->segment(1).'/accounting-jurnal')?>" class="btn btn-box-tool" data-toggle="tooltip" title="Kembali Ke Manage Laporan Kelas"> <i class="fa fa-arrow-circle-left"></i> Back</a>
        <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="Refresh Page" onclick='location.reload();'>
          <i class="fa fa-refresh"></i> Refresh</button>
      </div>
    </div>
    <div class="box-body">
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab"><b>Informasi Kelas Reguler</b></a></li>
              <li><a href="#tab_2" data-toggle="tab"><b>Laporan Biaya dan Pendapatan Kelas</b></a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
                 <table class="table table-bordered table-striped" style="width: 100%">
		    <tr>
        		<td valign="top" width="300">Nama Kelas & Angkatan (Baku)</td>
        		<td valign="top" width="20">:</td>
        		<td valign="top" style="color:#9900cc"><?=$data->DescBaku_Kelas_n_Angkatan?></td>
        	</tr>
        	<tr>
        		<td valign="top">Nama Kelas & Angkatan (Ketikan Bebas)</td>
        		<td valign="top">:</td>
        		<td valign="top" style="color:#9900cc"><?=$data->DescBebas_Kelas_n_Angkatan?></td>
        	</tr>
        	<tr>
        		<td valign="top">Jenis Pelatihan</td>
        		<td valign="top">:</td>
        		<td valign="top" style="color:#9900cc"><?=$data->Desc_JenisPelatihan?></td>
        	</tr>
        	<tr>
        		<td valign="top">Perusahaan / Instansi</td>
        		<td valign="top">:</td>
        		<td valign="top" style="color:#9900cc"><?=$data->Desc_PershInstansi?></td>
        	</tr>
        	<tr>
        		<td valign="top">Angkatan Ke</td>
        		<td valign="top">:</td>
        		<td valign="top" style="color:#9900cc"><?=$data->No_Urut_Angkatan?></td>
        	</tr>
        	<tr>
        		<td valign="top">Kode Singkatan Kelas tsb.</td>
        		<td valign="top">:</td>
        		<?php
                    $kode = "-";
                    if($data->KODE_Singkatan != null){
                        $kode = $data->KODE_Singkatan;
                    }
                ?>
        		<td valign="top" style="color:#9900cc"><?=$kode?></td>
        	</tr>
        	<tr>
        		<td valign="top">Kota Tempat Pelatihan</td>
        		<td valign="top">:</td>
        		<?php
                    $kota = "-";
                    if($data->Desc_KotaTraining != null){
                        $kota = $data->Desc_KotaTraining;
                    }
                ?>
        		<td valign="top" style="color:#9900cc"><?=$kota?></td>
        	</tr>
        	<tr>
        		<td valign="top">Lokasi Penyelenggaraan</td>
        		<td valign="top">:</td>
        		<?php
                    $lokasi = "-";
                    if($data->LokasiPenyelenggaraan != null){
                        $lokasi = $data->LokasiPenyelenggaraan;
                    }
                ?>
        		<td valign="top" style="color:#9900cc"><?=$lokasi?></td>
        	</tr>
        	<tr>
        		<td valign="top">Jumlah Peserta</td>
        		<td valign="top">:</td>
        		<td valign="top" style="color:#9900cc"><?=$data->Jml_Peserta?> Peserta</td>
        	</tr>
        	<tr>
        		<td valign="top">Tanggal Mulai</td>
        		<td valign="top">:</td>
        		<td valign="top" style="color:#9900cc"><?=tgl_indo($data->Tgl_Mulai_Aktual)?></td>
        	</tr>
        	<tr>
        		<td valign="top">Tanggal Selesai</td>
        		<td valign="top">:</td>
        		<td valign="top" style="color:#9900cc"><?=tgl_indo($data->Tgl_Selesai_Aktual)?></td>
        	</tr>
        	<tr>
        		<td valign="top">Lama Hari Pelatihan</td>
        		<td valign="top">:</td>
        		<td valign="top" style="color:#9900cc"><?=$data->LamaHariPelatihan?> Hari</td>
        	</tr>
        	<tr>
        		<td valign="top">Status Kelas Saat ini</td>
        		<td valign="top">:</td>
        		<?php
        			$selesai = "";
        			if($data->Flag_Selesai == "B"){
        				$selesai = "Kelas Belum Dimulai";
        			}
        			elseif($data->Flag_Selesai == "L"){
        				$selesai = "Kelas Sedang Berlangsung";
        			}
        			elseif($data->Flag_Selesai == "E"){
        				$selesai = "Kelas Sudah Berakhir";
        			}
        			elseif($data->Flag_Selesai == "C"){
        				$selesai = "Kelas Sudah Ditutup";
        			}
        		?>
        		<td valign="top" style="color:#9900cc"><?=$selesai?></td>
        	</tr>
        </table>  
              </div> <!-- /.tab-pane -->
              
              <div class="tab-pane" id="tab_2">
                <div class="container-fluid">    
                    <div class="col-md-6">
                        <div class="box box-success">
                        <div class="box-header with-border">
                          <i class="fa fa-sign-out"></i>
                          <h3 class="box-title">Transaksi Debet</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                          <dl>
                            <dd class="pull-right">
                                <?php
                                  foreach ($debet->result() as $d) { ?>
                                    <?="<span class='pull-right'>Rp. ".number_format($d->Nilai_Rps)."</span><br/>"?>  
                                <?php } ?>
                            </dd>
                            <dd class="pull-left">
                                <?php
                                  foreach ($debet->result() as $d) { ?>
                                    <?=$d->Desc_Transaksi. " : <br/>"?>  
                                <?php } ?>
                            </dd>
                          </dl>
                        </div> <!-- /.box-body -->
                      </div> <!-- /.box -->
                    </div> <!-- /.col -->
                    
                    <div class="col-md-6">
                        <div class="box box-success">
                        <div class="box-header with-border">
                          <i class="fa fa-sign-in"></i>
                          <h3 class="box-title">Transaksi Kredit</h3>
                        </div>
                        
                        <!-- /.box-header -->
                        <div class="box-body">
                          <dl>
                            <dd class="pull-right">
                                <?php
                                  foreach ($kredit->result() as $k) { ?>
                                    <?="<span class='pull-right'>Rp. ".number_format($k->Nilai_Rps)."</span><br/>"?>  
                                <?php } ?>
                            </dd>
                            <dd class="pull-left">
                                <?php
                                  foreach ($kredit->result() as $k) { ?>
                                    <?=$k->Desc_Transaksi. " : <br/>"?>  
                                <?php } ?>
                            </dd>
                          </dl>
                        </div> <!-- /.box-body -->
                      </div> <!-- /.box -->
                    </div> <!-- /.col -->
                    
                    <div class="col-md-12">
                        <div class="box" style="border-top:0px solid">
                        <div class="box-header with-border">
                          <h3 class="box-title pull-right" ><b>Total Kredit (Rp.)</b></h3>
                        </div>
                        <?php
                          $totalk = 0;
                          $nilair = 0;
                          foreach ($debet->result() as $d) {
                            $nilair += $d->Nilai_Rps;
                          } 
                          foreach ($kredit->result() as $k) {
                            $totalk += $k->Nilai_Rps;
                          } 
                        ?>
                        <!-- /.box-header -->
                        <div class="box-body">
                          <dl>
                            <dd class="pull-right">
                                <?="<b class='pull-right'>Rp. ".number_format($totalk)."</b><br/>"?> <hr/>
                                <?php
                                  foreach ($debet->result() as $d) { ?>
                                    <?="<b class='pull-right'>Rp. ".number_format($d->Nilai_Rps)."</b><br/>"?>  
                                <?php } ?>
                                <hr style="border: 1px solid red;">
                                <?="<b style='font-size:26px'>Rp. ".number_format($totalk - $nilair)."</b>"?>
                            </dd>
                          </dl>
                        </div> <!-- /.box-body -->
                      </div> <!-- /.box -->
                    </div> <!-- /.col -->
                </div>
              </div> <!-- /.tab-pane -->
            </div> <!-- /.tab-content -->
          </div> <!-- nav-tabs-custom -->
    </div>
  </div>
</section>
