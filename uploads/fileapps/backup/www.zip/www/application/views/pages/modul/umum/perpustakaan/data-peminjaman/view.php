<table class="table table-bordered table-striped" style="width: 100%">
	<tr>
		<td valign="top">Nama Anggota</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->nama_anggota?></td>
	</tr>
	<tr>
		<td valign="top">Judul Buku</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->judul_buku?></td>
	</tr>
	<tr>
		<td valign="top">Jumlah Buku</td>
		<td valign="top">:</td>
		<td valign="top"><?=$dtdefault->jml_pinjam?></td>
	</tr>
	<tr>
		<td valign="top">Tanggal Pinjam</td>
		<td valign="top">:</td>
		<td valign="top"><?=tgl_indo($dtdefault->tgl_pinjam)?></td>
	</tr>
	<tr>
		<td valign="top">Jadwal Kembali</td>
		<td valign="top">:</td>
		<td valign="top"><?=tgl_indo($dtdefault->tgl_kembali)?></td>
	</tr>
</table>