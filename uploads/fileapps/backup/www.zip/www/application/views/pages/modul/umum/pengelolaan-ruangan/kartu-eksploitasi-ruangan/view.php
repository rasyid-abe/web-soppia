<table class="table table-bordered table-striped" style="width: 100%">
	<tr>
		<td valign="top">No Ruangan</td>
		<td valign="top">:</td>
		<td valign="top">5465</td>
	</tr>
	<tr>
		<td valign="top">Nama Ruangan</td>
		<td valign="top">:</td>
		<td valign="top">Ruangan Depan 1</td>
	</tr>
	
</table>
<table class="table table-bordered table-striped" style="width: 100%">

	<tr><header style="text-align: center; font-size: 20px">PEMELIHARAAN RUANGAN</header></tr>
	<tr>
		<td valign="top">Jangka Waktu Pemeliharaan</td>
		<td valign="top">:</td>
		<td valign="top">10/11/2018 - 11/11/2018</td>
	</tr>
	<tr>
		<td valign="top">Penanggung Jawab</td>
		<td valign="top">:</td>
		<td valign="top">Ahmad Santoso</td>
	</tr>
	<tr>
		<td valign="top">Biaya</td>
		<td valign="top">:</td>
		<td valign="top">Rp 100.000.000</td>
	</tr>
	
	<tr>
		<td valign="top">Keterangan</td>
		<td valign="top">:</td>
		<td valign="top">Ruangan Baru</td>
	</tr>
	
</table>
<table class="table table-bordered table-striped" style="width: 100%">

	<tr><header style="text-align: center; font-size: 20px">PEMAKAIAN RUANGAN</header></tr>
	<tr>
		<td valign="top">Penanggung Jawab</td>
		<td valign="top">:</td>
		<td valign="top">Ahmad Subekti</td>
	</tr>
	<tr>
		<td valign="top">Jangka Waktu Peminjaman Pemakaian</td>
		<td valign="top">:</td>
		<td valign="top">10/11/2018 - 11/11/2018</td>
	</tr>
	<tr>
		<td valign="top">Keterangan</td>
		<td valign="top">:</td>
		<td valign="top">Rapat Keluarga</td>
	</tr>
	
</table>
