<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
	Title Browser / judul aplikasi
*/
$config['appname'] = 'Sopia';
$config['version'] = '1.2.6.7';

?>