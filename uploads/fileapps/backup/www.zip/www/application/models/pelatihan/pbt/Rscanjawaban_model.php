<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Rscanjawaban_model extends CI_Model {
 
}